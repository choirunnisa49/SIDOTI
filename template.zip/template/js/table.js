function iconTable(x) {
    x.classList.toggle("fa-plus");
    $('#body-table').slideToggle(500);
}

function iconForm(x) {
    x.classList.toggle("fa-plus");
    $('#body-form').slideToggle(500);
}